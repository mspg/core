const div = document.getElementById('js')
div.innerHTML = 'if this is visible, javascript works!'
